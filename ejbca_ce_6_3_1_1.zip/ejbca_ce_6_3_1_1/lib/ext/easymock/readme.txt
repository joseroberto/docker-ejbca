
These are jars used for external activities, not needed for running CESeCore.


Used to create mocks for unit testing purposes. EasyMock and dependencies. (license Apache 2.0):
easymock-3.0.jar
objensis-1.2.jar
cglib-nodep-2.2.jar

