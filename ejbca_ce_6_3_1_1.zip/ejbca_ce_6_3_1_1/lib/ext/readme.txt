
These are jars used for external activities, not needed for running EJBCA.

External dependencies used just for building (java classes):
servlet-2.3.jar
mailapi.jar (javaMail v1.4.3)

User to build docs (license apache):
jdom-b9.jar (I think)
velocity-dep-1.4.jar

Used to run regular JUnit tests (license CPL):
junit-4.11.jar

Used to run Http/Html specific JUnit tests (license apache like...see doc/licenses/LICENSE_HTMLUNIT):
htmlunit-1.14.jar
commons-httpclient-3.1.jar

Used to compile XKMS without need to have both jaxb from java 6 and jaxb RI present. (license is java open source, CDDL v1.1 and GPL v2).
jaxb-NamespacePrefixMapper-interfaces-2.0.0.jar
