XStream jars used for XML serialization of database tables

xmlpull-1.1.3.1.jar   http://xml.apache.org/xalan-j/  					Apache License Version 2.0.
xpp3_min-1.1.4c.jar   http://www.extreme.indiana.edu/xgws/xsoap/xpp/  	BSD License 
xstream-1.4.2.jar     http://xstream.codehaus.org/   					BSD License 
