
Old hibernate jars are only needed when we need to communicate with older versions of JBoss. 
I.e. 5 and 6.
 
Hibernate jars are from Hibernate (http://hibernate.org), License is LGPLv2.1.
This applies to all hibernate and javassist jars in this directory.

