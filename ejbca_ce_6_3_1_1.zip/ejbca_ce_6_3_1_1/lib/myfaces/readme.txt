
The MyFaces jars are from http://myfaces.apache.org/. License is Apache.

tomahawk-1.1.14.jar for JSF 1.1
