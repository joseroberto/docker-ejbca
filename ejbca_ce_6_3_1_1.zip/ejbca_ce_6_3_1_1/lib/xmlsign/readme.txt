
XMLSecurity is used by XKMS.

xalan-2.7.1.jar         http://xml.apache.org/xalan-j/  Apache License Version 2.0.
serializer-2.7.1.jar    http://xml.apache.org/xalan-j/  Apache License Version 2.0.
xmlsec-1.4.3.jar        http://santuario.apache.org/    Apache License Version 2.0.
