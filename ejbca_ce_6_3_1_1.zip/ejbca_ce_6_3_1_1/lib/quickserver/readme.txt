
Quickserver v 1.4.7, http://www.quickserver.org/, License is LGPLv2.1 or later.
All jars in this directory are from this distribution.